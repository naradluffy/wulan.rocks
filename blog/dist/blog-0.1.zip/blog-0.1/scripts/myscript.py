
class HelloWorld:
    """A simple example class"""
    i = 12345

    def __str__(self):
		return "hello world"